var ftj = function() {
	var h, w, a, s, act, cp, morph, imc, imcc, img, imgc, dcq, pfl, gimc, pfm, pfm_max, pfc, pfc_max, tabcal, tabcal_max;

	// Constantes
	var imc_comments = [ { s: 100, c: 'Ob�sit� massive ou morbide' }, { s: 40, c: 'Ob�sit� s�v�re' }, { s: 35, c: 'Ob�sit� mod�r�e ou commune' }, { s: 30, c: 'Surpoids' }, { s: 25, c: 'Normal' }, { s: 18.5, c: 'D�nutrition mod�r�e' }, { s: 17, c: 'D�nutrition' }, { s: 16, c: 'D�nutrition assez s�v�re' }, { s: 13, c: 'D�nutrition s�v�re' }, { s: 10, c: 'D�nutrition tr�s s�v�re' } ];

	var img_comments = new Array();
	img_comments[0] = [ { s: 100, c: 'en exc�s de graisse' }, { s: 20, c: 'normal' }, { s: 15, c: 'trop maigre' } ];
	img_comments[1] = [ { s: 100, c: 'en exc�s de graisse' }, { s: 30, c: 'normal' }, { s: 25, c: 'trop maigre' } ];

	var ftj_sexe = [ { v:0, l:'Masculin' }, { v:1, l:'F�minin' } ];
	var ftj_morph = [ { v:0, l:'Mince' }, { v:1, l:'Normale' }, { v:2, l:'Large' } ];
	var ftj_activites = [ { v:1.25, l:'S�dentaire' }, { v:1.3, l:'L�g�re' }, { v:1.5, l:'Moyen' }, { v:1.7, l:'Intense' }, { v:2.0, l:'Tr�s intense' } ];

	var ftj_coef_activities = [ { l:'sprint', c:0.134 }, { l:'stairs', c:0.116 }, { l:'running', c: 0.1 }, { l:'aerobics', c:0.088 }, { l:'racquet', c:0.081 }, { l:'chopping', c:0.080 }, { l:'dancing', c:0.076 }, { l:'swimming', c:0.071 }, { l:'skiing', c:0.068 }, { l:'basketball', c:0.063 }, { l:'jogging', c:0.061 }, { l:'walking', c:0.054 }, { l:'tennis', c:0.050 }, { l:'cycling', c:0.045 }, { l:'grocery', c:0.028 }, { l:'walkingslow', c:0.022 }, { l:'bowling', c:0.021 }, { l:'sitting', c:0.009 } ];

	return {

	setEnv:function(args) {
		h = args.h||181;
		w = args.w||78;
		a = args.a||40;
		s = args.s||0;
		act = args.act||1.5;
		cp = args.cp||16;
		morph = args.morph||2;
		imc = 0; imcc = ''; img = 0; imgc = ''; dcq = 0; pfl = 0; gimc = 0; pfm = 0; pfm_max = 0; pfc = 0; pfc_max = 0; tabcal = 0; tab_cal_max = 0;
	},
	
	round:function(num) { return (Math.round(num*100)/100); },

	getCaloriesBurn:function(coef, duration) {
		return (w > 0 ? Math.round(coef*w*(duration/60)) : 0);
	},
	
	getProfile:function(args) {
		ftj.setEnv(args);

		if (a < 3 || a > 100) { alert('Ce test est valide pour les personnes de plus de 3 ans et de moins de 100 ans'); return false; }
		if (w < 30 || w > 200) { alert('Ce test est valide pour les personnes de plus de 30 kg et de moins de 200 kg'); return false; }

		imc = ftj.round(w/eval((h/100)*(h/100)));
		for(i = 0; i < imc_comments.length; i++) if (imc < imc_comments[i].s) imcc = imc_comments[i].c;
		gimc = ftj.round(22*eval((h/100)*(h/100)));
		
		var ww = (s == 0 ? 66 + (13.7 * w) : 655 + (9.6 * w));
		var hh = (s == 0 ? 5 * h : 1.7 * h);
		var aa = (s == 0 ? 6.8 * a : 4.7 * a);
		dcq = Math.round(ww + hh - aa) * act;

		// poids de forme lorentz
		pfl = s == 0 ? (h - 100 - (h - 150) / 4) : (h - 100 - (h - 150) / 2.5);

		// poids de forme monnerot
		pfm = (h-100+4*cp)/2;
		pfm_max = ((h-100+4*cp)/2)+((h-100+4*cp)/2)*0.1 

		// poids de forme creff
		if (morph==0) {
			pfc = ftj.round((h-100+(a/10))*0.9*0.9);
			pfc_max = ftj.round(((h-100+(a/10))*0.9*0.9)+((h-100+(a/10))*0.9*0.9)*0.1);
		} else if (morph==1) {
			pfc = ftj.round((h-100+(a/10))*0.9);
			pfc_max = ftj.round(((h-100+(a/10))*0.9)+((h-100+(a/10))*0.9)*0.1);
		} else {
			pfc = ftj.round((h-100+(a/10))*0.9*1.1);
			pfc_max = ftj.round(((h-100+(a/10))*0.9*1.1)+((h-100+(a/10))*0.9*1.1)*0.1);
		}

		// Calories depensees selon tablescalories.com
		if (a < 10)			tabcal = s == 0 ? Math.round(w*22.7+495) : Math.round(w*22.5+499);
		else if (a < 18)	tabcal = s == 0 ? Math.round(w*17.5+651) : Math.round(w*12.2+746);
		else if (a < 30)	tabcal = s == 0 ? Math.round(w*15.3+679) : Math.round(w*14.7+496);
		else if (a < 60)	tabcal = s == 0 ? Math.round(w*11.6+879) : Math.round(w*8.70+829);
		else 				tabcal = s == 0 ? Math.round(w*13.5+487) : Math.round(w*10.5+596); 

		if (act == 1.25 || act == 1.3) tabcal_max = s == 0 ? Math.round(tabcal*1.55) : Math.round(tabcal*1.56);
		else if (act == 1.5)           tabcal_max = s == 0 ? Math.round(tabcal*1.78) : Math.round(tabcal*1.64);
		else                           tabcal_max = s == 0 ? Math.round(tabcal*2.10) : Math.round(tabcal*1.82);

		img = ftj.round( ((1.2 * imc) + (0.23 * a) - (10.8 * (s == 0 ? 1 : 0)) - 5.4) );
		for(i = 0; i < img_comments[s].length; i++) if (img < img_comments[s][i].s) imgc = img_comments[s][i].c;

		return { imc: imc, img: img, gimc: gimc, pfl: pfl, imc_comment: imcc, img_comment: imgc, dcq: dcq, pfm: pfm, pfm_max: pfm_max, pfc: pfc, pfc_max: pfc_max, tabcal: tabcal, tabcal_max: tabcal_max };
	}

	};
}();
