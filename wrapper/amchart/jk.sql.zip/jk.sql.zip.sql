# phpMyAdmin SQL Dump
# version 2.5.3
# http://www.phpmyadmin.net
#
# Serveur: localhost
# G�n�r� le : Vendredi 13 Avril 2012 � 17:27
# Version du serveur: 4.0.15
# Version de PHP: 4.3.3
# 
# Base de donn�es: `jk`
# 

# --------------------------------------------------------

#
# Structure de la table `jb_personnal_tracking`
#

CREATE TABLE `jb_personnal_tracking` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` int(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `type` int(11) NOT NULL default '0',
  `start_time` varchar(16) NOT NULL default '',
  `duration` varchar(16) NOT NULL default '',
  `distance` varchar(16) NOT NULL default '',
  `kcal` varchar(16) NOT NULL default '',
  `pulse` float NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Structure de la table `jb_users`
#

CREATE TABLE `jb_users` (
  `id` int(11) NOT NULL auto_increment,
  `nom` varchar(64) NOT NULL default '',
  `poids` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Structure de la table `player`
#

CREATE TABLE `player` (
  `id` int(11) NOT NULL auto_increment,
  `nom` varchar(64) NOT NULL default '',
  `prenom` varchar(64) NOT NULL default '',
  `age` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `id_2` (`id`)
) TYPE=MyISAM;

# --------------------------------------------------------

#
# Structure de la table `stats_globales`
#

CREATE TABLE `stats_globales` (
  `id` int(11) NOT NULL auto_increment,
  `year` int(16) NOT NULL default '0',
  `sum_visites` int(11) NOT NULL default '0',
  `avg_visites` int(11) NOT NULL default '0',
  `visites` text NOT NULL,
  `sum_uniques` int(11) NOT NULL default '0',
  `avg_uniques` int(11) NOT NULL default '0',
  `uniques` text NOT NULL,
  `sum_pages` int(11) NOT NULL default '0',
  `avg_pages` int(11) NOT NULL default '0',
  `pages` text NOT NULL,
  `last_update` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;
